<?php
header("location: ./home/community.php");
exit();
